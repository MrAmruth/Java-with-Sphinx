/*
Program Name: Speech Recognized Media Player Project
Description: This program implements Speech Recognition Framework called Sphinx
			 with Java Media Framework media player. User can say commands to
			 open, play, pause, stop, no(mute) and yes(unmute) the player
             
Expected Inputs: Inputs either with mouse/keyboard or voice commands work. For
				 example user can say player play or hello pause.
Expected Outputs: The player should trigger the events according to user inputs.
				  Outputs such as Play, Open, Pause, etc should work voice commands.

*/
package TME3_Q1;

//libraries
import edu.cmu.sphinx.frontend.util.Microphone;
import edu.cmu.sphinx.recognizer.Recognizer;
import edu.cmu.sphinx.result.Result;
import edu.cmu.sphinx.util.props.ConfigurationManager;
import edu.cmu.sphinx.*;
import javax.speech.*;
import WSJ_8gau_13dCep_16k_40mel_130Hz_6800Hz.*;
import java.io.*;
import java.awt.BorderLayout;
import java.awt.Component;
import java.net.URL;
import javax.media.CannotRealizeException;
import javax.media.*;
import javax.swing.JPanel;
import javax.swing.*;
import java.net.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.EventQueue;
import javax.swing.ImageIcon;
import java.awt.*;
///////////

public class TME3_1 
{
	
	/////////////////
	  static JFrame jDemo = new  JFrame ("Demo"); //Frame to hold all controls
	  static JPanel jMenu = new JPanel(); 	//Panel to hold "Open" button
	  static JPanel jPanel = new JPanel();	//Panel to hold player
	  static URL URLLink;					//stores the media file location
	  static JFileChooser jFile = new JFileChooser();	//open file dialog
	  static JButton openButton = new JButton("Open");	//button to open file dialog
	  static JSplitPane jSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT);	//split pane to arrange jPanel and jMenu
	  static Player pMedia;					//media player
	  static Time iPlayerTime;				//gets the time the video is paused
	/////////////////
	
	public static void main(String args[])
	{
		//Sphinx object controls all the configurations required for speech recognition
		ConfigurationManager cm = new ConfigurationManager(TME3_1.class.getResource("myconfig.xml"));
		//Sphinx voice recognition module
		Recognizer recognizer = (Recognizer)cm.lookup("recognizer");
		recognizer.allocate();
		//Sphinx microphone module
		Microphone microphone = (Microphone)cm.lookup("microphone");
		
		////////////////////////
		jDemo.setSize(200, 200);	//set default player size
	    jMenu.setSize(200, 20);		//set menu size to add "Open" button
	    jMenu.add(openButton);
	    jMenu.setVisible(true);
	    
	    jDemo.add(jMenu, BorderLayout.NORTH);	//adds menu panel to top of the frame
	    jDemo.add(jPanel, BorderLayout.CENTER);	//adds player to the center 
	    //jDemo.add(openButton);
	    jDemo.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //default close is set to exit
	    jDemo.setLocationRelativeTo(null);
	    jDemo.setVisible(true); 
	    
	    //open button calls onButtonPress event which would trigger open file dialog
	    openButton.addActionListener(new ActionListener() {
	        public void actionPerformed (ActionEvent e)
	        {
	           if (e.getSource() == openButton){
	              onButtonPress();
	           } 
	        }
	    });
	    
	    openButton.setVisible(true);
		
		//checks if microphone is connected to computer and configured properly
		if(!microphone.startRecording())
		{
			System.out.println("Cannot start microphone.");
			//speech recognition module is deallocated
			recognizer.deallocate();
			System.exit(1); //exits with microphone error
		}
		//provide the following options to user
		System.out.println("Say: (Player | Hello) ( Open | Stop | Pause| Play | Close | No  | Yes )");
		
		//infinite loop to hear user speak
		do 
		{
			System.out.println("Start speaking. Press Ctrl-C to quit.\n");
			//stores the speech to a result
			Result result = recognizer.recognize();
			if(result != null) 
			{
				//converts the word spoken by user to a text
				String resultText = result.getBestFinalResultNoFiller();
				System.out.println((new StringBuilder()).append("You said: ").append(resultText).append('\n').toString());
				//if user wants to open file dialog
				if(resultText.equals("hello open") || resultText.equals("player open"))
				{	
					onButtonPress();
				}
				//if user wants to stop a video
				if(resultText.equals("hello stop") || resultText.equals("player stop"))
				{
					StopPlayer();
				}
				//if(resultText.equals("hello record") || resultText.equals("player record"))
				//{
				//	ClosePlayer();
				//}
				//if user wants to pause a video
				if(resultText.equals("hello pause") || resultText.equals("player pause"))
				{
					PausePlayer();
				}
				//if player wants to play a video from pause
				if(resultText.equals("hello play") || resultText.equals("player play"))
				{
					PlayPlayer();
				}
				//if user wants to mute a video
				if(resultText.equals("hello no") || resultText.equals("player no"))
				{
					MutePlayer();
				}
				//if user wants to unmute a video
				if(resultText.equals("hello yes") || resultText.equals("player yes"))
				{
					UnmutePlayer();
				}
				//if user wants to close player -- program will not close
				if(resultText.equals("hello close") || resultText.equals("player close"))
				{
					ClosePlayer();
				}
			}
			//cannot match the word user has spoken
			else 
			{
				System.out.println("I can't hear what you said.\n");
			}
		} while(true);
	}
	
	
/*
    Method Name: onButtonPress
    Expected Inputs: None
    Expected output: None
    Purpose: This function is called when "Open" button is pressed. This opens a file dialog to
    		 choose a media file and calls a function that loads the file
*/
	public static void onButtonPress()
	  {
		//gets integer value from file open option  
		int iResult = jFile.showOpenDialog(null);
	    URLLink = null; //reset link      
	    //openFile(iResult);
	    if(iResult == jFile.APPROVE_OPTION)
	    {
	            
	    	try
	    	{
	    		//get the location of the media file
	    		URLLink = jFile.getSelectedFile().toURL();
	    	}
	    	catch (Exception e)
	    	{
	    		System.out.println(e.toString());
	    	}       
	        
	    	if(URLLink != null)
	    	{
	    		StopPlayer(); //stops player if a video is currently playing
	    		//set the frame to exit on close
	    		jDemo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    		//load the player with the chosen media file
	    		LoadPlayer(URLLink); 
	    		jDemo.add(jPanel);
	    		jPanel.setSize(600, 600); //resize the panel size
	    		jDemo.setVisible(true);
	    	}
	     }
	  }

/*
    Method Name: LoadPlayer
    Expected Inputs: URLlk - location of a media file chosen by user
    Expected output: None
    Purpose: This function loads a file chosen by user and plays the file
*/
	  public static void LoadPlayer(URL URLlk)
	  {
		  jPanel.setLayout( new BorderLayout());
		  //sets a light renderer version of media player
		  Manager.setHint(Manager.LIGHTWEIGHT_RENDERER, true);
		  try
		  {	  
	    	  //create player using the file chosen by user
			  pMedia = Manager.createRealizedPlayer(URLlk);
	      
			  //add video stream to player and controllers for player like pause/play
			  Component video = pMedia.getVisualComponent();
			  Component controls = pMedia.getControlPanelComponent();
		      
			  if(video != null)
			  {        
				  jPanel.add(video, BorderLayout.CENTER); //add video to center of panel  
			  }
			  if(controls != null)
			  {
				  jPanel.add(controls, BorderLayout.SOUTH); //add controls to bottom of panel
			  }
		      
			  //starts playing media file
			  pMedia.start();  
		  }
		  catch (Exception e)
		  {
			  System.out.println(e.toString());
		  }        
	  }

/*
    Method Name: StopPlayer
    Expected Inputs: None
    Expected output: None
    Purpose: Stops the player and clears the screen
*/
	  public static void StopPlayer()
	  {
		  //checks is a player exists
		  if(pMedia != null)
		  {	  
			  pMedia.close(); //closes the player
			  jPanel.removeAll(); //clears the screen
		  }
	  }

/*
    Method Name: ClosePlayer
    Expected Inputs: None
    Expected output: None
    Purpose: Closes the player
*/
	  public static void ClosePlayer()
	  {
		  //checks is a player exists
		  if(pMedia != null)
		  {			  
			  //closes and deallocates the player
			  pMedia.close(); 
			  jPanel.removeAll();
			  pMedia.stop();
			  pMedia.deallocate();
		  }
		  //closes the frame and removes it
		  jDemo.dispose();

          jDemo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  }
	  
/*
    Method Name: PausePlayer
    Expected Inputs: None
    Expected output: None
    Purpose: gets the player time when the video is paused and pauses the video
*/
	  public static void PausePlayer()
	  {
		  //checks if a player exists
		  if(pMedia != null)
		  {
			  //gets the current time of video 
			  iPlayerTime = pMedia.getMediaTime();
			  pMedia.stop();
		  }		  
	  }
	  
/*
    Method Name: PlayPlayer
    Expected Inputs: None
    Expected output: None
    Purpose: sets the player time when the video needs to play from
*/
	  public static void PlayPlayer()
	  {
		  //check is player has a video
		  if(pMedia != null && iPlayerTime != null)
		  {
			  //sets the player video to paused time and plays the video from that time
			  pMedia.setMediaTime(iPlayerTime);
			  pMedia.start();
		  }		  
	  }

/*
    Method Name: MutePlayer
    Expected Inputs: None
    Expected output: None
    Purpose: mutes the sound, cuts the audio stream
*/
	  public static void MutePlayer()
	  {
		  //if player is playing a video
		  if(pMedia != null && iPlayerTime != null)
		  {
			  pMedia.getGainControl().setMute(true); //set mute to true
		  }
		  
	  }
	  
/*
    Method Name: UnmutePlayer
    Expected Inputs: None
    Expected output: None
    Purpose: Unmutes the sound
*/
	  public static void UnmutePlayer()
	  {
		  //if player is playing a video
		  if(pMedia != null && iPlayerTime != null)
		  {
			  pMedia.getGainControl().setMute(false); //set mute to false
		  }
		  
	  }	  	
}